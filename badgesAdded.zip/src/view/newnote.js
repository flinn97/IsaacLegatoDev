import React, { Component } from 'react';

class Newnote extends Component {
    constructor(props) {
        //create state
        super(props);

        this.state = {
            
        };
    }
    
  
    
    render() {
        let app = this.props.app;
        let state = app.state;
        let styles = state.styles;
        let note= state.currentComponent;
        let opps = note?.getOperationsFactory();
        let dispatch= app.dispatch;
        let currentstudent = state.currentstudent;
        let key = note?.getJson().collection !==""? "update": "add"
        return (
            <div style={{
                background: "white", display:"flex", flexDirection:"column", justifyContent:"center",   }}>
            <div style={{
                background: "white", display:"flex", flexDirection:"column", justifyContent:"center", width:"100%" }}>
                <div style={{fontSize:"12px", marginLeft:"7px", color:"gray"}}>new note</div>
                <textarea  onClick={dispatch.bind(this, {popupSwitch:"notes", operate:"addnotes", object:{owner: currentstudent.getJson()._id}})} type="text" className="form-control" rows="1" id="description" onChange={opps?.handleChange} placeholder={note?.getJson().description? note?.getJson().description: "Start Typing..."} name={key+"description"} ></textarea>
                <button  className="btn  btn-block"  onClick={dispatch.bind(this, {operation:"run", popupSwitch:""})} 
                style={{
                    alignSelf:"flex-end", cursor:"pointer"
                }}>submit</button>

            </div>   
            </div>
        );
    }
}

export default Newnote;