import React, { Component } from 'react';
import Progress_circle from './components/progresscircle.js';
import Progressbar from './components/moreProgress.js';
import starpointService from '../services/starpointService.js';
import progress from '../assets/starpoints.png';
import badges from '../assets/bages.png';

class Progress extends Component {
    constructor(props) {
        //create state
        super(props);
        this.state = {
            
        };
    }
    

    render() {
        
        let app = this.props.app;
        let dispatch= app.dispatch;
        let state = app.state;
        let styles=state.styles;
       let currentstudent = this.props.app.state.currentstudent;
       let studentJson = currentstudent?.getJson();
       let comp = state.componentList; 
       let mainList = comp?.getList("mainGoal", studentJson._id);
       let goalList = comp?.getList("goal", studentJson._id);
      let badgeList = comp?.getList("badge", studentJson._id);
        
        return (
            <div style={
                styles.tallcard
                }>
            <div
                style={{
                        display:"flex", 
                        flexDirection:"row",
                        justifyContent:"flex-end",
                        alignItems: "right",
                        width:"100%",
                        fontWeight: styles.fonts.fontweightMed,
                        padding: styles.margins.margin4,

                        background: ""
                        //+ "88"
                        ,
                        borderRadius: "23px 23px 0px 0px",
                        fontSize: styles.fonts.fontsizeTitle,
                        fontFamily: styles.fonts.appFont,
                        fontWeight: styles.fonts.fontweightMain,
                        marginBottom: styles.margins.margin4,

                        
                 }}><div
                 style={
                    styles.buttons.buttonExpand
                }
                 >See all progress</div>
                 </div>
                 
            <div style={{display:"flex", flexDirection:"column", justifyContent:"center", display:"flex", alignItems:"center"}}>
               {/* <Progress_circle dispatch={dispatch} maingoals={mainList} goals={goalList} update={state.updateCircle} /> */}
               <img style={{}} src={progress} alt="starpoints" />
               <Progressbar dispatch={dispatch} text="points"  day={false} amount={1} goal={2}/>
               <div style={{width:"100%",marginTop:"20px"}}><p style={{marginLeft:"40px"}}>Badge Collection</p></div>
               
               <div style={{display:"flex", flexDirection:"row"}}>{badgeList.slice(0,3)?.map((badge, index)=>
               <img src={badge.getJson().picURL} style={{width:"75px"}}/>)}
               </div>
               {/* <Progressbar dispatch={dispatch} text="Days Practiced:" day={true} amount={studentJson.daysPracticed} goal={studentJson.totalDays} />
               <Progressbar dispatch={dispatch} text="Time Practiced:" time={true} amount={studentJson.timeTotal} goal={studentJson.wmin} /> */}
               
               
               {state.currentuser.getJson().role!=="student" && (<div 
                    style={{
                        padding: this.props.app.state.styles.margins.margin5,
                        cursor:"pointer",
                        border: "0px solid #000000", 
                        borderRadius: "9px",
                        height: this.props.app.state.styles.margins.margin3,
                        marginTop: this.props.app.state.styles.margins.margin4,
                        
                        background: this.props.app.state.myswitch==="chat" ? styles.colors.colorBackground:"",
                        color: styles.colors.color3,
                        
                        color: this.props.app.state.myswitch==="chat" ? styles.colors.color3:styles.colors.color3,
                        fontWeight: this.props.app.state.myswitch==="chat" ? styles.fonts.fontweightMed:styles.fonts.fontweightMain,
                    }} 
                onClick={this.props.app.dispatch.bind(this,{popupSwitch:"addBadge", operate:"addbadge", operation:"cleanJsonPrepare", object:{owner:currentstudent.getJson()._id}})}>Create Badge</div>)}
            </div>
            </div>

               
        );
    }
}

export default Progress;