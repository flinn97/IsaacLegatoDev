import React, { Component } from 'react';
import Studentinfo from './studentinfo.js';
import Homework from "./homework.js";
import Progress from "./progress.js";
import Goals from './goals.js';
import Notes from './notes.js';
import Stats from './stats.js';
import EditProgress from './popups/editProgress.js';
import "../view.css"
import Chat from './studentChat.js';
/**
 * teacher
 */
class Studentview extends Component {
    constructor(props) {
        //create state
        super(props);
        this.state = {
            
        };
    }
    

    render() {
        let app=this.props.app;
        let state= app.state;
        let styles=state.styles;
        let dispatch=app.dispatch;

        return (

                <div style={{display:"flex", flexDirection:"column", justifycontent:"center", marginLeft:styles.margins.margin3}}>
                    <button onClick={dispatch.bind(this,{popupSwitch:"syncStudent"})}>syncStudent</button>
                    {state.currentstudent.getJson()._id}
                    {state.popupSwitch==="editStudent"?(<EditProgress handleClose={dispatch.bind(this,{popupSwitch:""})} app = {app} />):(<></>)}
                    <div style={{display:"flex", flexDirection:"row"}}>
                        <div
                    style={{marginTop:styles.margins.margin4}}></div>
                    <div onClick = {dispatch.bind(this,{popupSwitch:"editStudent",  operate: "update", operation:"cleanPrepare", object:state.currentstudent })}>edit</div>
                    </div>
                    <div style={{display:"flex", flexDirection:"row", justifycontent:"center" }}>
                    
                        <Homework app={app}  />
                        <Progress  app={app} />
                    </div>
                    <div style={{display:"flex", flexDirection:"row", }}>

                        <Goals app={app} />
                        {state.currentuser.role==="student"?( <Stats  app={app}/>):(
                        <Notes app={app}/>)}
                        {state.currentuser.role==="student"?(<Chat app={app} />):(<Chat app={app} />)}
                    </div>
                </div>

        );
    }
}

export default Studentview;