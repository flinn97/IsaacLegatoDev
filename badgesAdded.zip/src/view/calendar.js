import React, { Component } from "react";


class Calendar extends Component {
    constructor(props) {
        super(props);
      

        this.state = {
        

    };
}
    
    
   
    render() {
        let app=this.props.app;
        let state= app.state;
        let styles=state.styles;
        let dispatch=app.dispatch;

        return (
            <div 
            style={styles.biggestcard }>
                    <div style= {{
                        padding: this.props.app.state.styles.margins.margin4,
                        fontSize: this.props.app.state.styles.fonts.fontsizeTitle,
                        fontFamily: this.props.app.state.styles.fonts.appFont,
                        fontWeight: this.props.app.state.styles.fonts.fontweightMed,
                        justifycontent:"center",

                    }}>Calendar</div>
                <div style={{
                    display:"flex", 
                    flexDirection:"column", 
                    marginRight:this.props.app.state.styles.margins.margin4,
                    padding: this.props.app.state.styles.margins.margin4,
                    fontSize: this.props.app.state.styles.fonts.fontsize1,
                    //background: index%2===0 ? this.props.app.state.styles.colors.colorTransparent+"AA":"" 
            }}>{this.props.app.state.appointments.Monday.map((student, index) =><div key={index} >{student.firstName}</div>)} </div>
                <div style={{
                    isplay:"flex", 
                    flexDirection:"column", 
                    marginRight:this.props.app.state.styles.margins.margin4,
                    padding: this.props.app.state.styles.margins.margin4,
                    fontSize: this.props.app.state.styles.fonts.fontsize1,
                    //background: index%2===0 ? this.props.app.state.styles.colors.colorTransparent+"AA":""             
                    }}>{this.props.app.state.appointments.Tuesday.map((student, index) =><div key={index} >{student.firstName}</div>)}</div>
                <div style={{
                    isplay:"flex", 
                    flexDirection:"column", 
                    marginRight:this.props.app.state.styles.margins.margin4, 
                    padding: this.props.app.state.styles.margins.margin4,
                    fontSize: this.props.app.state.styles.fonts.fontsize1,
                    //background: index%2===0 ? this.props.app.state.styles.colors.colorTransparent+"AA":""  
            }}>{this.props.app.state.appointments.Wednesday.map((student, index) =><div key={index} >{student.firstName}</div>)}</div>
                <div style={{
                    display:"flex", 
                    flexDirection:"column", 
                    marginRight:this.props.app.state.styles.margins.margin4, 
                    padding: this.props.app.state.styles.margins.margin4,
                    fontSize: this.props.app.state.styles.fonts.fontsize1,
                    //background: index%2===0 ? this.props.app.state.styles.colors.colorTransparent+"AA":""  
            }}>{this.props.app.state.appointments.Thursday.map((student, index) =><div key={index} >{student.firstName}</div>)}</div>
                <div style={{
                    isplay:"flex", 
                    flexDirection:"column", 
                    marginRight:this.props.app.state.styles.margins.margin4, 
                    padding: this.props.app.state.styles.margins.margin1,
                    fontSize: this.props.app.state.styles.fonts.fontsize1,
                    //background: index%2===0 ? this.props.app.state.styles.colors.colorTransparent+"AA":""  
            }}>{this.props.app.state.appointments.Friday.map((student, index) =><div key={index} >{student.firstName}</div>)}</div>
                <div style={{
                    isplay:"flex", 
                    flexDirection:"column", 
                    marginRight:this.props.app.state.styles.margins.margin4, 
                    padding: this.props.app.state.styles.margins.margin1,
                    fontSize: this.props.app.state.styles.fonts.fontsize1,
                   // background: index%2===0 ? this.props.app.state.styles.colors.colorTransparent+"AA":""  
            }}>{this.props.app.state.appointments.Saturday.map((student, index) =><div key={index} >{student.firstName}</div>)}</div>
                <div style={{
                    isplay:"flex", 
                    flexDirection:"column", 
                    marginRight:this.props.app.state.styles.margins.margin4, 
                    padding: this.props.app.state.styles.margins.margin1,
                    fontSize: this.props.app.state.styles.fonts.fontsize1,
                    //background: index%2===0 ? this.props.app.state.styles.colors.colorTransparent+"AA":""  
            }}>{this.props.app.state.appointments.Sunday.map((student, index) =><div key={index} >{student.firstName}</div>)}</div>
                </div>

        );
    }
}

export default Calendar;