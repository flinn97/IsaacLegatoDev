import React, { Component } from 'react';
class Menu extends Component {
    constructor(props) {
        //create state
        super(props);
        this.state = {
            
        };
    }
    

    render() {
        let app = this.props.app;
        let state = app.state;
        let styles =state.styles;
        let dispatch = app.dispatch;
        let list = state.componentList;

       
        return (
            <div 
                    style={{
                        display:"flex", 
                        flexDirection:"column", 
                        textAlign: "center",
                        color: styles.colors.color1,
                        fontWeight: styles.fonts.fontweightMed,
                        fontFamily: styles.fonts.appTitle,
                        fontSize: styles.fonts.fontsize1,
                        fontWeight: styles.fonts.fontweightMain,
                        width: "88%",
                        flex: .59,
                        font: styles.fonts.fontSide,

                        }}>
                {state.currentuser.getJson().type==="student"?(<div 
                    style={{
                        cursor:"pointer",
                        
                        background: state.myswitch==="dash" ? styles.colors.colorBackground:"",
                    }}
                onClick={()=>{
                    //debugger
                    window.history.pushState({state: "StudentDashboard"}, "page 1", "dashboard")
                    this.props.app.dispatch({myswitch:"studentDash"})}}>Dashboard</div>
                ):(<div 
                    style={{
                        padding: this.props.app.state.styles.margins.margin5,
                        cursor:"pointer",
                        border: "0px solid #000000", 
                        borderRadius: "9px",
                        height: this.props.app.state.styles.margins.margin3,
                        marginTop: this.props.app.state.styles.margins.margin4,

                        background: this.props.app.state.myswitch==="dash" ? styles.colors.colorBackground:"",
                        
                        color: this.props.app.state.myswitch==="dash" ? styles.colors.color3:styles.colors.color3,
                        fontWeight: this.props.app.state.myswitch==="dash" ? styles.fonts.fontweightMed:styles.fonts.fontweightMain,
                    }} 
                onClick={()=>{
                    //debugger
                    window.history.pushState({state: "dash"}, "page 2", "dashboard")
                    this.props.app.dispatch(this.props.app.state.switch.dashboard)}}>Dashboard</div>)}

                {state.currentuser.getJson().role==="student"?(<div style={{cursor:"pointer",}} onClick={this.props.app.dispatch.bind(this,this.props.app.state.switch.teacher)}>My Teacher</div>):(
                <a href="http://localhost:3000/legato/calendar"
                    style={{
                        textDecoration:"none",
                        padding: this.props.app.state.styles.margins.margin5,
                        cursor:"pointer",
                        border: "0px solid #000000", 
                        borderRadius: "9px",
                        height: this.props.app.state.styles.margins.margin3,
                        marginTop: this.props.app.state.styles.margins.margin4,
                        
                        background: this.props.app.state.myswitch==="calendar" ? styles.colors.colorBackground:"",

                        color: this.props.app.state.myswitch==="calendar" ? styles.colors.color3:styles.colors.color3,
                        fontWeight: this.props.app.state.myswitch==="calendar" ? styles.fonts.fontweightMed:styles.fonts.fontweightMain,
                    }} 
                onClick={this.props.app.dispatch.bind(this,this.props.app.state.switch.calendar)}>Calendar</a>)}
                <div 
                    style={{
                        padding: this.props.app.state.styles.margins.margin5,
                        cursor:"pointer",
                        border: "0px solid #000000", 
                        borderRadius: "9px",
                        height: this.props.app.state.styles.margins.margin3,
                        marginTop: this.props.app.state.styles.margins.margin4,
                        
                        background: this.props.app.state.myswitch==="chat" ? styles.colors.colorBackground:"",
                        color: styles.colors.color3,
                        
                        color: this.props.app.state.myswitch==="chat" ? styles.colors.color3:styles.colors.color3,
                        fontWeight: this.props.app.state.myswitch==="chat" ? styles.fonts.fontweightMed:styles.fonts.fontweightMain,
                    }} 
                onClick={this.props.app.dispatch.bind(this,this.props.app.state.switch.chat)}>Chat</div>

            </div>

               
        );
    }
}

export default Menu;