import React, { Component } from "react";
// import Form from "react-validation/build/form";
// import Input from "react-validation/build/input";
// import { isEmail } from "validator";
import Dropdown from "./dropdown.js"
import Down from "./downarrow.png"
import authService from "../../services/auth.service.js";
import "../../App.css"
import './pages.css';
import './components.css';
import './index.css';
import './view.css';
import clock from "./clock.png"
import calendarService from "../../services/calendarService.js";
import Wolf from '../../assets/place1.png';
import dear from '../../assets/place2.png';
import sheep from '../../assets/place3.png';
import cat from '../../assets/place4.png';
import bird from '../../assets/place5.png';
import turkey from '../../assets/place6.png';
import bug from '../../assets/place7.png';
// import factory from "../../npm/factory.js";
//this component details my dialog help component

class Addstudent extends Component{
    //using the functions sent from the profile page allows me to send back student information typed in to profile and then to the backend. 
    constructor(props) {
        super(props);
        this.wrapperRef = React.createRef();
        this.handleClickOutside = this.handleClickOutside.bind(this);
        this.selectDay = this.selectDay.bind(this);
        this.selectDays = this.selectDays.bind(this);
        this.selectTime = this.selectTime.bind(this);
        this.closedrop = this.closedrop.bind(this);
        this.changeTime = this.changeTime.bind(this);
        this.handleChange= this.handleChange.bind(this);
        // this.addstudent=this.addstudent.bind(this);
        this.getSchedule= this.getSchedule.bind(this);
        this.setWrapperRef = this.setWrapperRef;
        this.state = {
           days: [],
           pics: [Wolf, dear, sheep, cat, bird, turkey, bug],
           sched:{},
            daily: "100",
            currentDay: "",
            hwtype: "",
            showHomework: false,
            currentHomework: undefined,
            currentgoal: undefined,
            showGoals: false,
            tempID: 1,
            HWtempID:1,
            tempGoal: "",
            tempDescription: "",
            tempday: "",
            tempcheckboxes: "",
            tempHW: "",
            edited: false,
            edit: "",
            editedd: "",
            val: false,
            yesnoCheckboxes: true,
            yesnoTime: true,
            timeframePractice: true,
            starPoints: true,
            manualsetup: false,
            syncCheckbox: true,
            dayorweekTime: "",
            timeSync: true,
            daysbool: true,
            timebool: true,
            smonths: "",
            emonths: "",
            temonths: "",
            tsmonths: "",
            Supporting_Goal: "",
            Homework_Practiced: "",
            timeframePracticebiao: true,
            min: "100",
            weeklytimebiao: "60",
            dailytimebiao: true,
            dmin: "20",
            weekStreak: true,
            dayStreak: true,
            done: 0,
            hwsynccheck: true,
            hwdmin: "",
            HWweeklytimebiao: "",
            hwtimesync: true,
            hwlink: "",
            struggles: true,
            hwQuestions: true,
            yesnoday: true,
            yesnoweek: true,
            marginTop: "",
            marginLeft: "55px",
            selectDay: false,
            selectTime: false,
            day: "",
            time: "",
            first:"",
            last: "",
            time: "",
            toosmall: false,
            
        }
    }
    handleChange = (event) => {
        const { name, value } = event.target
        this.setState({
            [name]: value,
        })
    }
    componentDidMount() {
        document.addEventListener('mousedown', this.handleClickOutside);
    }
    componentWillUnmount() {
        document.removeEventListener('mousedown', this.handleClickOutside);
    }
    handleClickOutside(event) {
        if (this.wrapperRef && !this.wrapperRef.current.contains(event.target)) {
            this.props.handleClose();
        }
    }
   
    
    selectDay() {
        this.setState({
            selectDay: !this.state.selectDay,
        })
    }
    closedrop() {
        this.setState({
            selectDay: false,
            selectTime: false,

        })
    }
    selectTime(day) {
        
        this.setState({
            [day+"selectTime"]: !this.state[day+"selectTime"],
            currentDay:day
            
        })
    }
    getSchedule(time){
        let aschedule = "";
        let ampm=""
        for (let i = 0; i < time.length; i++) {
            if (time[i] !== ":") {
                if (i === 0 && time[i] !== "0") {
                    aschedule = aschedule + time[i];
                    if(parseInt(time[i+1])>1){
                        ampm=" pm"
                    }
                    else{
                        ampm=" am"
                    }
                }
                else if(i === 0 && time[i] === "0"){
                    ampm=" am"
                }
                else if (i > 0) {
                    
                    aschedule = aschedule + time[i];
                }
                
            }
        }
        aschedule +=ampm;
        return aschedule;
    }

    selectDays(day) {
        let arr = [...this.state.days];
        arr.push(day)
                this.setState({
            days: arr
        })
    }
    changeTime(time, showtime) {
        let app = this.props.app;
        let styles= this.props.app.state.styles;
        let comp = this.props.app.state.componentList;
        let operate= comp.getOperationsFactory();
        let student = operate.getUpdater().getJson().add[0];
        let times = this.getSchedule(time);
        let sched = {...this.state.sched};
        sched[this.state.currentDay] =times;
        this.setState({
            sched:sched,
            [this.state.currentDay+"time"]: showtime
        })
        this.selectTime(this.state.currentDay);
    }

    render() {
        let app = this.props.app;
        let styles= this.props.app.state.styles;
        let comp = this.props.app.state.componentList;
        let operate= comp.getOperationsFactory();
        let student = operate.getUpdater().getJson().add[0];
        return (
            <div className="popup-box" style ={{
                zIndex: "10000",
            }}>
                <div className="box_add" ref={this.wrapperRef}>
                    <span className="close-icon-2" style= {{color:"#8C6057"}} onClick={this.props.handleClose}>x</span>
                    <div>
                        <div className="form-group">
                            <label htmlFor="firstName"><b>Student First Name:</b>*</label>
                            <input
                                type="text"
                                className="form-control"
                                id="first"
                                onChange={operate.handleChange}
                                name="addfirstName"
                            />
                        </div>
                        <div className="form-group">
                            <label htmlFor="lastName"><b>Student Last Name:</b>*</label>
                            <input
                                type="text"
                                className="form-control"
                                id="last"
                                onChange={operate.handleChange}
                                name="addlastName"
                            />
                        </div>
                            <div className="form-group forfiles" >
                                
                                <div>
                                    <label htmlfor="day"><b>Days: </b></label>
                                    <div style={{flexDirection:"row", display:'flex', }}>
                                        <p onClick={this.selectDays.bind(this,"Monday")} style={{color:this.state.days.includes("Monday")&&"white", backgroundColor:this.state.days.includes("Monday")&&"blue"}}>Mon </p>
                                        <p onClick={this.selectDays.bind(this,"Tuesday")} style={{color:this.state.days.includes("Tuesday")&&"white", backgroundColor:this.state.days.includes("Tuesday")&&"blue"}}>Tues </p>
                                        <p onClick={this.selectDays.bind(this,"Wednesday")} style={{color:this.state.days.includes("Wednesday")&&"white", backgroundColor:this.state.days.includes("Wednesday")&&"blue"}}>Wed </p>
                                        <p onClick={this.selectDays.bind(this,"Thursday")} style={{color:this.state.days.includes("Thursday")&&"white", backgroundColor:this.state.days.includes("Thursday")&&"blue"}}>Thur </p>
                                        <p onClick={this.selectDays.bind(this,"Friday")} style={{color:this.state.days.includes("Friday")&&"white", backgroundColor:this.state.days.includes("monday")&&"blue"}}>Fri </p>
                                        <p onClick={this.selectDays.bind(this,"Saturday")} style={{color:this.state.days.includes("Saturday")&&"white", backgroundColor:this.state.days.includes("monday")&&"blue"}}>Sat </p>
                                        <p onClick={this.selectDays.bind(this,"Sunday")} style={{color:this.state.days.includes("Sunday")&&"white", backgroundColor:this.state.days.includes("monday")&&"blue"}}>Sun </p>
                                        </div>
                                </div>

                        </div>
                        {this.state.days?.map((day, index) => 
                        <div> <h3 onClick={()=>{
                            let arr = [...this.state.days];
                            arr = arr.filter(word=>word!==day);
                            let sched = {...this.state.sched};
                            let s ={}
                            for(const key in sched){
                                if(key!==day){
                                    s[key]= sched[key]
                                }
                            }
                            this.setState({days:arr, sched:s});
                        }}>X</h3> <div key={index}>{day}</div><div>
                        <label htmlfor="time"><b>Scheduled Time:</b></label>
                        <div className="form-control" id="time" onClick={this.selectTime.bind(this, day)} style={{ width: "120px", height: "30px", flexDirection: "row", display: "flex" }}>
                            <div style={{ width: "90px", alignSelf: "center" }}>{this.state[day+"time"]}</div>
                            <img src={clock} alt="clock" style={{ width: "15px", height: "15px", }} />
                        </div>
                        {this.state[day+"selectTime"] ? (<Dropdown selectDay={this.selectDays} clock={true} closedrop={this.closedrop} changeTime={this.changeTime}/>) : (<div></div>)}
                    </div></div>
                        )}
                        <div style={{ marginTop: "50px" }}>
                                <button className="btn " style={{background:"#696eb5", color:"#F0F2EF" }} onClick=
                                {async ()=>{
                                    //debugger
                                    let picURL= this.state.pics[Math.floor(Math.random()*(7-1))]
                                    await student.setJson({...student.getJson(), picURL: picURL});
                                    await student.changeSchedule(this.state.sched);
                                    await operate.run();
                                    
                                    await operate.cleanJsonPrepareRun({
                                        addstarpoints:{owner: student.getJson()._id}, 
                                        addchatroom:{name:student.getJson().firstName, owner:student.getJson()._id, people:{[student.getJson()._id]:student.getJson().lastName}}});

                                    await authService.register(student.getJson()._id +"@legato.com", student.getJson()._id);
                                    await authService.registerStudent({email:app.state.email}, student.getJson()._id);
                                    app.dispatch({studentAdded:true});
                                    // await operate.JsonPrepareRun({addchatroom:{name:student.getJson().firstName, people:{[student.getJson()._id]:student.getJson().lastName}}});
                                    
                                    this.props.handleClose();
                                    }}>Add Student</button>
                            </div>
                    </div>
                </div>
            </div>

        )
    }
};

export default Addstudent;
