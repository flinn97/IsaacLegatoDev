import React, { Component } from "react";
import studentService from "../../services/studentService";
//details my existingEmail.js component. creates some buttons that use methods embedded in props from the profile page. Choice will update the backend.
class StudentSync extends Component {
    constructor(props) {
        super(props);
        this.wrapperRef = React.createRef();
        this.handleClickOutside = this.handleClickOutside.bind(this);
        this.setWrapperRef = this.setWrapperRef;
        this.state = {
            studentList: [],
        }
    };
    async componentDidMount() {
        
        let app = this.props.app;
        let state = app.state;
        let student= state.currentstudent;
        let componentList = state.componentList;
        let studentIDs = student.getJson().syncedStudents
        
        let arr=[];
        let list =Object.keys(studentIDs).length>0?[]: [ student];
        for(const key in studentIDs){
            if(studentIDs[key]===student.getJson()._id){
                arr.unshift(studentIDs[key]);
                list.unshift(student);
            }
            else{
                arr.push(studentIDs[key]);
                let syncstudent = componentList.getComponent("student", studentIDs[key], "_id");
                list.push(syncstudent);
            }
            
        }

        
        this.setState({studentList:list, studentIDs:arr})
        
        document.addEventListener('mousedown', this.handleClickOutside);
    }
    componentWillUnmount() {
        document.removeEventListener('mousedown', this.handleClickOutside);
    }
    handleClickOutside(event) {
        if (this.wrapperRef && !this.wrapperRef.current.contains(event.target)) {
            this.props.handleClose();
        }
    }

    render() {
        let app = this.props.app;
        let state = app.state;
        let styles = state.styles;
        let student= state.currentstudent;
        let opps = student?.getOperationsFactory();
        let dispatch= app.dispatch;
        let componentList = state.componentList;

        
        return (
            <div className="popup-box" style={{ zIndex: "1010" }}>
                <div ref={this.wrapperRef}  className="diapicboxa" style={{ zIndex: "1010" }}>
                    <span className="close-icon-2" onClick={this.props.handleClose}>x</span>
                        Sync: 
                        <div style={{display:'flex', flexDirection:"row"}}>{this.state.studentList?.map((s, index) => 
                    <div key={index}  onClick={()=>{
                        //debugger
                        let arr = [...this.state.studentIDs];
                        let list = [...this.state.studentList];
                        let i = 0
                        for(i; i<arr.length; i++){
                            if(arr[i]===s.getJson()._id){
                                arr.splice(i, 1);
                                list.splice(i, 1);
                                break;
                            }
                        }
                        this.setState({studentList:list, studentIDs: arr});
                    }}> {s.getJson().firstName}</div>
                    )}</div>
                    from
                    {componentList.getList('student').map((s, index) => 
                    <div>{(s.getJson()._id!==student.getJson()._id && !this.state.studentIDs?.includes(s.getJson()._id))&&(
                    <div key={index} onClick={()=>{
                        
                        let arr = [...this.state.studentIDs];
                        arr.push(s.getJson()._id)
                        let list = [...this.state.studentList];
                        list.push(s);
                        this.setState({studentList:list, studentIDs: arr});
                    }}> {s.getJson().firstName}</div>)}</div>
                    )}
                    <div>
                    {state.popupSwitch==="archive"?(<></>):(
                    <button className="btn  btn-block" style={{ background: "#696eb5", height: "35px", color: "#F0F2EF" }} 
                    onClick={async ()=>{
                        //debugger
                        await student.sync(this.state.studentList);
                        dispatch({ popupSwitch:""});
                        }}>Sync
                    </button>
                    )}
                    </div>





            </div>
            </div>

        )
    }
};

export default StudentSync;