import React, { Component } from 'react';
import clock from "./clock.png";
import Dropdown from './dropdown';
import Down from './downarrow.png'
export default class EditProgress extends Component {
    constructor(props) {
        super(props);
        this.wrapperRef = React.createRef();
        this.setWrapperRef = this.setWrapperRef;
        this.handleClickOutside = this.handleClickOutside.bind(this);
        this.handleChange=this.handleChange.bind(this);
        this.selectTime=this.selectTime.bind(this);
        this.selectDay=this.selectDay.bind(this);
        this.selectDays=this.selectDays.bind(this);
        this.changeTime=this.changeTime.bind(this);
        this.dispatch=this.dispatch.bind(this);
        this.closedrop = this.closedrop.bind(this);
        this.getSchedule=this.getSchedule.bind(this);
        this.state = {
            // first: this.props.app.state.currentstudent.firstName,
            // last: this.props.app.state.currentstudent.lastName,
            // username: this.props.app.state.currentstudent.username,
            // scheduling: this.props.app.state.currentstudent.scheduling,
            // starPoints: this.props.app.state.currentstudent.starPoints,
            day: this.props.app.state.currentstudent.day,
            // email: this.props.app.state.currentstudent.email,
            // phone: this.props.app.state.currentstudent.phone,
            // totalDaysPracticed: this.props.app.state.currentstudent.totalDaysPracticed,
            // totalDays: this.props.app.state.currentstudent.totalDays,
            // timeTotal: this.props.app.state.currentstudent.timeTotal,
            // totaltime: this.props.app.state.currentstudent.totaltime,
            // time: this.props.app.state.currentstudent.time,
            // checked: this.props.app.state.currentstudent.syncedCheckbox,
            // daysPracticed: this.props.app.state.currentstudent.daysPracticed,
            // wmin: this.props.app.state.currentstudent.wmin,
            day: this.props.app.state.currentstudent?.getJson()?.day,
            scheduling: "",
            selectTime:false,
            selectDay:false,
            days:[]
            // showtime: this.props.app.state.currentstudent.scheduling
        }
    }
    componentDidMount() {
        //debugger
        let sched = this.props.app.state.currentstudent?.getJson()?.days
        let obj={}
        for(const key in sched){
            obj[key+"time"]=sched[key]
        }
        this.setState({sched:sched, days: Object.keys(sched), ...obj});
        document.addEventListener('mousedown', this.handleClickOutside);
    }
    componentWillUnmount() {
        document.removeEventListener('mousedown', this.handleClickOutside);
    }
    handleClickOutside(event) {
        if (this.wrapperRef && !this.wrapperRef.current.contains(event.target)) {
            this.props.handleClose();
        }
    }
    dispatch(obj){
        
        this.setState({
            [Object.keys(obj)[0]]: obj[Object.keys(obj)[0]]
        })
    }
    handleChange = (event) => {
        let { name, value } = event.target
        if(value==="true"||value==="false"){
            value= value==="true"?true:false
        }
        this.setState({
            [name]: value,
        })
    }
    selectDays(day) {
        let arr = [...this.state.days];
        arr.push(day)
                this.setState({
            days: arr
        })
    }
    selectDay() {
        this.setState({
            selectDay: !this.state.selectDay,
        })
        
    }
    closedrop() {
        this.setState({
            selectDay: false,
            selectTime: false,

        })
    }
    getSchedule(time){
        let aschedule = "";
        let ampm=""
        for (let i = 0; i < time.length; i++) {
            if (time[i] !== ":") {
                if (i === 0 && time[i] !== "0") {
                    aschedule = aschedule + time[i];
                    if(parseInt(time[i+1])>1){
                        ampm=" pm"
                    }
                    else{
                        ampm=" am"
                    }
                }
                else if(i === 0 && time[i] === "0"){
                    ampm=" am"
                }
                else if (i > 0) {
                    
                    aschedule = aschedule + time[i];
                }
                
            }
        }
        aschedule +=ampm;
        return aschedule;
    }
    changeTime(time, showtime) {
        let app = this.props.app;
        let styles= this.props.app.state.styles;
        let comp = this.props.app.state.componentList;
        let operate= comp.getOperationsFactory();
        let student = operate.getUpdater().getJson().add[0];
        let times = this.getSchedule(time);
        let sched = {...this.state.sched};
        sched[this.state.currentDay] =times;
        this.setState({
            sched:sched,
            [this.state.currentDay+"time"]: showtime
        })
        this.selectTime(this.state.currentDay);
    }
    selectTime(day) {
        
        this.setState({
            [day+"selectTime"]: !this.state[day+"selectTime"],
            currentDay:day
            
        })
    }
    render() {
        let app = this.props.app;
        let state = app.state;
        let dispatch = app.dispatch;
        let component = state.currentstudent;
        let compJson = component?.getJson();
        let opps = component?.getOperationsFactory();
        return (
            <div className="popup-boxa to-front" style={{ }} >

                <div ref={this.wrapperRef} className="card-container6abc1shedit" >
                    <div className="fill2 homeworkScroll1" >
                    <span className="close-icon-2" onClick={this.props.handleClose}>x</span>
                    <div style={{ width: "100%" }}>
                    <h2 style={{display:"flex", flexDirection:"row", justifyContent:this.state.justifyContent}}>Edit Student</h2>
                    <div className="form-group">
                            <label htmlFor="firstName"><b>First Name:</b></label>
                            <input type="text" className="form-control" id="first" placeholder={compJson?.firstName} onChange={opps?.handleChange} name="updatefirstName"/>
                        </div>
                        <div className="form-group">
                            <label htmlFor="lastName"><b>Last Name:</b></label>
                            <input type="text" className="form-control" id="last" placeholder={compJson?.lastName} onChange={opps?.handleChange} name="updatelastName"/>
                        </div>
                                <div>
                                    <label htmlfor="day"><b>Days: </b></label>
                                    <div style={{flexDirection:"row", display:'flex', }}>
                                        <p onClick={this.selectDays.bind(this,"Monday")} style={{color:this.state.days.includes("Monday")&&"white", backgroundColor:this.state.days.includes("Monday")&&"blue"}}>Mon </p>
                                        <p onClick={this.selectDays.bind(this,"Tuesday")} style={{color:this.state.days.includes("Tuesday")&&"white", backgroundColor:this.state.days.includes("Tuesday")&&"blue"}}>Tues </p>
                                        <p onClick={this.selectDays.bind(this,"Wednesday")} style={{color:this.state.days.includes("Wednesday")&&"white", backgroundColor:this.state.days.includes("Wednesday")&&"blue"}}>Wed </p>
                                        <p onClick={this.selectDays.bind(this,"Thursday")} style={{color:this.state.days.includes("Thursday")&&"white", backgroundColor:this.state.days.includes("Thursday")&&"blue"}}>Thur </p>
                                        <p onClick={this.selectDays.bind(this,"Friday")} style={{color:this.state.days.includes("Friday")&&"white", backgroundColor:this.state.days.includes("monday")&&"blue"}}>Fri </p>
                                        <p onClick={this.selectDays.bind(this,"Saturday")} style={{color:this.state.days.includes("Saturday")&&"white", backgroundColor:this.state.days.includes("monday")&&"blue"}}>Sat </p>
                                        <p onClick={this.selectDays.bind(this,"Sunday")} style={{color:this.state.days.includes("Sunday")&&"white", backgroundColor:this.state.days.includes("monday")&&"blue"}}>Sun </p>
                                        </div>
                                </div>
                                {this.state.days?.map((day, index) => 
                        <div> <h3 onClick={()=>{
                            let arr = [...this.state.days];
                            arr = arr.filter(word=>word!==day);
                            let sched = {...this.state.sched};
                            let s ={}
                            for(const key in sched){
                                if(key!==day){
                                    s[key]= sched[key]
                                }
                            }
                            this.setState({days:arr, sched:s});
                        }}>X</h3> <div key={index}>{day}</div><div>
                        <label htmlfor="time"><b>Scheduled Time:</b></label>
                        <div className="form-control" id="time" onClick={this.selectTime.bind(this, day)} style={{ width: "120px", height: "30px", flexDirection: "row", display: "flex" }}>
                            <div style={{ width: "90px", alignSelf: "center" }}>{this.state[day+"time"]}</div>
                            <img src={clock} alt="clock" style={{ width: "15px", height: "15px", }} />
                        </div>
                        {this.state[day+"selectTime"] ? (<Dropdown selectDay={this.selectDays} clock={true} closedrop={this.closedrop} changeTime={this.changeTime}/>) : (<div></div>)}
                    </div></div>
                        )}
                                <div className="form-group">
                            <label htmlFor="email"><b>Email:</b></label>
                            <input type="text" className="form-control" id="email" placeholder={compJson?.email} onChange={opps?.handleChange} name="updateemail"/>
                        </div>
                        <div className="form-group">
                            <label htmlFor="phone"><b>Phone Number:</b></label>
                            <input type="text"className="form-control"id="phone"placeholder={compJson?.phone}onChange={opps?.handleChange}name="updatephone"/>
                        </div>
                        <label>Should this student have daily checkboxes?</label>
                        {compJson?.check?(
                            <select  htmlFor="updatecheck" onChange={opps?.handleChange} name="updatecheck" id="updatecheck">
                            <option value={true}>Current: Yes</option>
                            <option value={false}>No</option>                                       
                        </select>
                        ):(
                            <select  htmlFor="updatecheck" onChange={opps?.handleChange} name="updatecheck" id="updatecheck">
                                        <option value={false}>Current:No</option>                                       
                                        <option value={true}>Yes</option>
                                    </select>
                        )}
                                    
                                    <div className="form-group" style={{  marginLeft: "55px" }}>
                                    <label>Should this student track time?</label>
                                    {compJson?.time?(
                            <select  htmlFor="time" onChange={opps?.handleChange} name="updatetime" id="time">
                            <option value={true}>Current: Yes</option>
                            <option value={false}>No</option>                                       
                        </select>
                        ):(
                            <select  htmlFor="time" onChange={opps?.handleChange} name="updatetime" id="time">
                                        <option value={false}>Current:No</option>                                       
                                        <option value={true}>Yes</option>
                                    </select>
                        )}
                                    </div>
                            <div className="form-group">
                                <label>Track Star Points?</label>
                                    {compJson?.starPoints?(
                                    <select htmlfor="starPoints" onChange={opps?.handleChange} name="updatestarPoints" id="starPoints">
                                    <option value={true}>Current: yes</option>
                                    <option value={false}>no</option>
                                    </select>):(
                                        <select htmlfor="starPoints" onChange={opps?.handleChange} name="updatestarPoints" id="starPoints">
                                        <option value={false}>Current: no</option>
                                        <option value={true}> yes</option>
                                        </select>
                                     )}
                            </div>
                            {/* <div> */}
                          {/* <div> */}
                                {/* <div className="form-group" >
                                <label htmlFor="totalDays">Days to practice:</label>
                                <input type="text" className="form-control" id="updatetotalDays" style={{ width: "60px" }} placeholder={compJson?.totalDays} onChange={opps?.handleChange} name="updatetotalDays"/>
                            </div>
                            <button className="btn btn-block" style={{ background: "#696eb5", height: "35px", color: "#F0F2EF", marginTop:"5px", width:"185px" }} 
                            onClick= {()=>{
                                this.setState({dayscleared:true});
                                opps?.componentDispatch({updatedaysPracticed:"0"}); }}>
                                {!this.state.dayscleared?(<span className="fill1"><p style={{ marginBottom: "10px" }}>Clear Days Practiced</p></span>):(<span className="fill1"><p style={{ marginBottom: "10px" }}>Days Cleared</p></span>)}</button>
                                <div>
                                    <div>
                                    <div className="form-group" >
                                    <label htmlFor="wmin">Practice minutes:</label>
                                    <input type="text" className="form-control" id="wmin" placeholder={compJson?.wmin} style={{ width: "60px" }} onChange={opps?.handleChange} name="updatewmin"/>
                                </div>
                                
                                <button className="btn btn-block" style={{ background: "#696eb5", height: "35px", color: "#F0F2EF", marginTop:"5px", width:"185px" }} 
                               onClick={()=>{
                                this.setState({timecleared:true});
                                opps?.componentDispatch({updatetimeTotalforGoal:"0"}); }}>{!this.state.timecleared?(<span className="fill1"><p style={{ marginBottom: "10px" }}>Clear Time Practiced</p></span>):(<span className="fill1"><p style={{ marginBottom: "10px" }}>Time Cleared</p></span>)}</button> */}


                                

                  
                                </div>
                                 <button className="btn btn-block" style={{ background: "#696eb5", height: "35px", color: "#F0F2EF", marginTop:"20px", width:"125px" }} onClick={async ()=>{
                                    component.changeSchedule(this.state.sched)
                                    dispatch({operation: "run", popupSwitch:""})}}>
                                <span className="fill1"><p style={{ marginBottom: "10px" }}>Save</p></span></button> 

                    </div>
                   
                    
                </div>
                    </div>
                // </div></div>
                // </div>
                // </div>
            

        )

    }
}
///                await this.props.app.dispatch({tick:1, myswitch:"noarray", switchV:true,miscswitch:true, day:day, objkey:"checked", objectattribute:day, realobject:{checked: mychecks}, sp:20, backendearr:["starpoints", "checked", "daysPracticed", "daystreak"], currentstudent: this.props.app.currentstudent?this.props.app.currentstudent: false})
