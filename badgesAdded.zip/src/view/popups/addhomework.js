import React, { Component } from "react";
import Checkedd from "../components/checkbox";
import Times from "./times";
import studentService from "../../services/studentService.js"
//details my existingEmail.js component. creates some buttons that use methods embedded in props from the profile page. Choice will update the backend.
class Addhomework extends Component {
    constructor(props) {
        super(props);
        this.wrapperRef = React.createRef();
        this.handleClickOutside = this.handleClickOutside.bind(this);
        this.edit = this.edit.bind(this);

        this.setWrapperRef = this.setWrapperRef;
        this.state = {
            edit: this.props.app.state.popupSwitch==="updateHomework"? true: false,
        }

    };
    componentDidMount() {
        document.addEventListener('mousedown', this.handleClickOutside);
    }
    componentWillUnmount() {
        document.removeEventListener('mousedown', this.handleClickOutside);
    }
    handleClickOutside(event) {
        if (this.wrapperRef && !this.wrapperRef.current.contains(event.target)) {
            if(!this.props.app.state.popupSwitch!=="addhwtime"){
                this.props.handleClose();
            }
        }
    }
    edit(){
        this.setState({ edit:!this.state.edit})
    }
    
    render() {
        let app = this.props.app;
        let state = app.state;
        let styles = state.styles;
        let homework= state.currentComponent;
        let opps = homework?.getOperationsFactory();
        let dispatch= app.dispatch;
        let mykey = state.popupSwitch;
        let key = opps?.getSplice(mykey);
        return (<div>
            
                                <div className="popup-box" style={{ zIndex: "1010" }}>
                <div ref={this.wrapperRef}  className="diapicboxa" style={{ zIndex: "1010", height:"50vh" }}>
                    
                <span className="close-icon-2" onClick={this.props.handleClose}>x</span>
               {state.popupSwitch==="updateHomework" &&(<div onClick={this.edit}>edit</div>)}
                 {this.state.edit?( <div style={{display: "flex", flexDirection:"column"}}>
                    {homework?.getJson().checked?(<Checkedd  size={styles.checkbox.size1} app={app} component={homework}  checked={homework.getJson().checked} time={homework.getJson().time} />):(<></>)}
                    <button  className="btn  btn-block"  onClick={dispatch.bind(this, {secondaryPopup:"addhwtime",  currentComponent:homework,})} style={{ background: "#696eb5", height: "30px", color: "#F0F2EF", width: "200px", display:"flex", flexDirection:"column", justifyContent:"center", alignItems:"center"}}>+ Time</button>
                    {state.secondaryPopup==="addhwtime" && (<Times  app={this.props.app} homework={homework}  handleClose={this.props.app.dispatch.bind(this, {popupSwitch:"", secondaryPopup:"",})} />)}
                    <div>{homework?.getJson().title}</div>
                    <div>{homework?.getJson().description}</div>
                    <div >{homework?.getJson().hwlink}</div>
                    
                    </div>):(
                    <div>
                        
                    <div >
                    <div className="form-group">
                        <label htmlFor="lastName"><b>Homework Name:</b></label>
                        <input type="text" className="form-control" id="homework" style={{width:"95%"}} onChange={opps?.handleChange} name={key+"title"} placeholder={homework?.getJson().title}/>
                    </div>
                        <div className="form-group">
                            <label>Describe the practice assignment.</label>
                                <textarea type="text" className="form-control" rows="3" id="hwdescription" onChange={opps?.handleChange} name={key+"description"} placeholder={homework?.getJson().description}></textarea>
                        </div>
                        <div className="form-group">
                            <label>Do you want to use checkboxes to track this practice assignment's progress? </label>
                                {this.props.app.popupSwitch==="updateHomework"?( <select htmlfor="check" onChange={opps?.handleChange} name={key+"check"} id="check">
                                        <option value={true}>yes</option>
                                        <option value={false}>no</option>
                                        </select>):(
                                     <select htmlfor="check" onChange={opps?.handleChange} name={key+"check"} id="check">
                                     {homework?.getJson()?.check? (<option value={true}>yes</option>):(<option value={false}>no</option>)}
                                     {homework?.getJson()?.check? (<option value={false}>no</option>):(<option value={true}>yes</option>)}
                                     </select>
                                )}
                                   
                                         
                        </div>
                        <div className="form-group">
                            <label>Do you want to use time to track this practice assignment's progress? </label>
                            {this.props.app.popupSwitch==="updateHomework"?(<select htmlfor="time" onChange={opps?.handleChange} name={key+"Time"} id="time">
                                    <option value={true}>yes</option>
                                    <option value={false}>no</option>
                                    </select>):(
                                    <select htmlfor="yesnoCheckbox" onChange={opps?.handleChange} name={key+"time"} id="yesnoCheckbox">
                                    {homework?.getJson()?.time? (<option value={true}>yes</option>):(<option value={false}>no</option>)}
                                        {homework?.getJson()?.time? (<option value={false}>no</option>):(<option value={true}>yes</option>)}
                                    </select>)}
                        </div> 
                        <div className="form-group">
                        <label htmlFor="lastName"><b>Add a Link:</b></label>
                        <input type="text" className="form-control" id="homework" style={{width:"95%"}} onChange={opps?.handleChange} name={key+"hwlink"} placeholder={homework?.getJson()?.hwlink}/>
                    </div>                   
                        <div style={{ marginTop: "20px", }}>
                        <button  className="btn  btn-block"  
                        onClick={dispatch.bind(this, {popupSwitch:"", operation:"run"})}
                        style={{ background: "#696eb5", height: "30px", color: "#F0F2EF", width: "200px", display:"flex", flexDirection:"column", justifyContent:"center", alignItems:"center"}}>+ Homework</button>
                    </div>
                    </div>
                </div>
                )}
                </div>
                
            </div>

            </div>)
    }
};
export default Addhomework;
//                        onClick={this.props.app.dispatch.bind(this, {objkey:"homeworks", obj:this.props.app.state.showhomework? {...this.props.app.homework}: undefined, myswitch:this.props.app.state.showhomework?"update": "add"})} 
