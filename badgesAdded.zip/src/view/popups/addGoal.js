import React, { Component } from "react";
import studentService from "../../services/studentService";
//details my existingEmail.js component. creates some buttons that use methods embedded in props from the profile page. Choice will update the backend.
class addGoal extends Component {
    constructor(props) {
        super(props);
        this.wrapperRef = React.createRef();
        this.handleClickOutside = this.handleClickOutside.bind(this);
        this.setWrapperRef = this.setWrapperRef;
        this.state = {
        }
    };
    async componentDidMount() {

        
        document.addEventListener('mousedown', this.handleClickOutside);
    }
    componentWillUnmount() {
        document.removeEventListener('mousedown', this.handleClickOutside);
    }
    handleClickOutside(event) {
        if (this.wrapperRef && !this.wrapperRef.current.contains(event.target)) {
            this.props.handleClose();
        }
    }

    render() {
        let app = this.props.app;
        let state = app.state;
        let styles = state.styles;
        let goal= state.currentComponent;
        let opps = goal?.getOperationsFactory();
        let dispatch= app.dispatch;
        let key = goal?.getJson().collection !==""? "update": "add"
        return (
            <div className="popup-box" style={{ zIndex: "1010" }}>
                <div ref={this.wrapperRef}  className="diapicboxa" style={{ zIndex: "1010" }}>
                    <span className="close-icon-2" onClick={this.props.handleClose}>x</span>
                    <div className="form-group">
                        <label htmlFor="lastName"><h5>Add Goal</h5></label>
                        <input
                            type="text"
                            className="form-control"
                            id="goal"
                            placeholder= {goal?.getJson().title}
                            onChange={opps?.handleChange}
                            name={key+"title"}
                        />
                    </div>
                    <div >
                        <label htmlFor="description"><h5>Description</h5></label>
                        <div className="form-group" >
                            <textarea
                                type="text"
                                className="form-control"
                                rows="4"
                                id="description"
                                placeholder= {goal?.getJson().title}
                                onChange={opps?.handleChange}
                                name={key+"description"}

                            ></textarea>
                        </div>

                    </div>
                   

                    <div>
                    {state.popupSwitch==="archive"?(<></>):(
                    <button className="btn  btn-block" style={{ background: "#696eb5", height: "35px", color: "#F0F2EF" }} 
                    onClick={dispatch.bind(this, {operation:"run", popupSwitch:""})}>Add goal
                    </button>
                    )}
                    </div>





                </div>
            </div>

        )
    }
};

export default addGoal;