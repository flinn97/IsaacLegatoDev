import React, { Component } from "react";
import studentService from "../../services/studentService";
import authService from "../../services/auth.service";
//details my existingEmail.js component. creates some buttons that use methods embedded in props from the profile page. Choice will update the backend.
class PicUpload extends Component {
    constructor(props) {
        super(props);
        this.wrapperRef = React.createRef();
        this.handleClickOutside = this.handleClickOutside.bind(this);
        this.changeHandler = this.changeHandler.bind(this);
        this.handleSubmission = this.handleSubmission.bind(this);

        this.setWrapperRef = this.setWrapperRef;
        this.state = {
        }
    };
    changeHandler = async (event) => {
        let opps = this.props.app.state.currentComponent?.getOperationsFactory();
        let path = "images/" + event.target.files[0].name;
        this.setState({
            selectedFile:event.target.files[0],
            path: path
        }) 
        await opps.componentDispatch(this.props.app.state.currentComponent.getJson().collection?{ updatepics: path}:{ addpics: path});
        
	};
    async handleSubmission()  {
        
        await authService.uploadPics(this.state.selectedFile, this.state.path);
        await this.props.app.state.currentComponent.getPicSrc();
        await this.props.app.state.currentComponent?.getOperationsFactory().run();
        
        this.props.app.dispatch({updatePics:true});
        this.props.handleClose();

	};
    async componentDidMount() {

        
        document.addEventListener('mousedown', this.handleClickOutside);
    }
    componentWillUnmount() {
        document.removeEventListener('mousedown', this.handleClickOutside);
    }
    handleClickOutside(event) {
        if (this.wrapperRef && !this.wrapperRef.current.contains(event.target)) {
            this.props.handleClose();
        }
    }

    render() {
        let app = this.props.app;
        let state = app.state;
        let styles = state.styles;
        let goal= state.currentComponent;
        let opps = goal?.getOperationsFactory();
        let dispatch= app.dispatch;
        let key = goal?.getJson().collection !==""? "update": "add"
        return (
            <div className="popup-box" style={{ zIndex: "1010" }}>
                <div ref={this.wrapperRef}  className="diapicboxa" style={{ zIndex: "1010" }}>
                    <span className="close-icon-2" onClick={this.props.handleClose}>x</span>
                   
                   <div class="mb-3">
                   <label for="formFile" class="form-label">Default file input example</label>
                   <input class="form-control" type="file" id="formFile" onChange={this.changeHandler}/>
                 </div>
                    <div>
                    {state.popupSwitch==="archive"?(<></>):(
                    <button className="btn  btn-block" style={{ background: "#696eb5", height: "35px", color: "#F0F2EF" }} 
                    onClick={this.handleSubmission}>Add pic
                    </button>
                    )}
                    </div>





                </div>
            </div>

        )
    }
};

export default PicUpload;