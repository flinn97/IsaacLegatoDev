import React, { Component } from "react";
import studentService from "../../services/studentService";
import badge1 from "../../assets/badges/badge1.png";
import badge2 from "../../assets/badges/badge2.png";
import badge3 from "../../assets/badges/badge3.png";
import badge4 from "../../assets/badges/badge4.png";
import badge5 from "../../assets/badges/badge5.png";
import badge6 from "../../assets/badges/badge6.png";

//details my existingEmail.js component. creates some buttons that use methods embedded in props from the profile page. Choice will update the backend.
class AddBadge extends Component {
    constructor(props) {
        super(props);
        this.wrapperRef = React.createRef();
        this.handleClickOutside = this.handleClickOutside.bind(this);
        this.setWrapperRef = this.setWrapperRef;
        this.state = {
            badges:[badge1, badge2, badge3,badge4,badge5,badge6],
            currentBadge:  badge1, 
        }
    };
    async componentDidMount() {

        let app = this.props.app;
        let state = app.state;
        let styles = state.styles;
        let badge= state.currentComponent
        let opps = badge?.getOperationsFactory();
        let dispatch= app.dispatch;
        let key ="add"
        debugger
        badge?.setJson({ ...badge.getJson(), picURL:this.state.currentBadge});
        

       document.addEventListener('mousedown', this.handleClickOutside);
    }
    componentWillUnmount() {
        document.removeEventListener('mousedown', this.handleClickOutside);
    }
    handleClickOutside(event) {
        if (this.wrapperRef && !this.wrapperRef.current.contains(event.target)) {
            this.props.handleClose();
        }
    }

    render() {
        let app = this.props.app;
        let state = app.state;
        let styles = state.styles;
        let badge= state.currentComponent
        let opps = badge?.getOperationsFactory();
        let dispatch= app.dispatch;
        let key ="add"
        return (
            <div className="popup-box" style={{ zIndex: "1010" }}>
                <div ref={this.wrapperRef}  className="diapicboxa" style={{ zIndex: "1010" }}>
                    <span className="close-icon-2" onClick={this.props.handleClose}>x</span>
                    <div style={{display:"flex", flexDirection:"row",}}>
                    <div>
                        <img src={this.state.currentBadge} style={{width:"75px"}}/>
                    <div className="form-group">
                        <label htmlFor="lastName"><h5>Badge Title</h5></label>
                        <input
                            type="text"
                            className="form-control"
                            id="badge"
                            placeholder= {badge?.getJson().title}
                            onChange={opps?.handleChange}
                            name={key+"title"}
                        />
                    </div>
                    <div >
                        <label htmlFor="description"><h5>Description</h5></label>
                        <div className="form-group" >
                            <textarea
                                type="text"
                                className="form-control"
                                rows="1"
                                id="description"
                                placeholder= {badge?.getJson().description}
                                onChange={opps?.handleChange}
                                name={key+"description"}

                            ></textarea>
                        </div>

                    </div>
                    </div>
                    <div>{this.state.badges.map((badgePic, index)=>
                    <img key = {index} onClick={async ()=>{
                        
                       await this.setState({currentBadge: badgePic})
                        state.currentComponent?.setJson({ ...state.currentComponent.getJson(), picURL:badgePic});
                       
                    }}style ={{width:"75px"}} src={badgePic}/>
                    )} </div>
                    </div>

                    <div>
                    {state.popupSwitch==="archive"?(<></>):(
                    <button className="btn  btn-block" style={{ background: "#696eb5", height: "35px", color: "#F0F2EF" }} 
                    onClick={dispatch.bind(this, {operation:"run", popupSwitch:"", })}>Add Badge
                    </button>
                    )}
                    </div>





                </div>
            </div>

        )
    }
};

export default AddBadge;