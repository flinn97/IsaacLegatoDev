import React, { Component } from 'react';
import clock from "./clock.png";
import Dropdown from './dropdown';
import Down from './downarrow.png'
export default class EditUser extends Component {
    constructor(props) {
        super(props);
        this.wrapperRef = React.createRef();
        this.setWrapperRef = this.setWrapperRef;
        this.handleClickOutside = this.handleClickOutside.bind(this);

        this.state = {

        }
    }
    componentDidMount() {
        document.addEventListener('mousedown', this.handleClickOutside);
    }
    componentWillUnmount() {
        document.removeEventListener('mousedown', this.handleClickOutside);
    }
    handleClickOutside(event) {
        if (this.wrapperRef && !this.wrapperRef.current.contains(event.target)) {
            this.props.handleClose();
        }
    }
    
    render() {
        let app = this.props.app;
        let state = app.state;
        let dispatch = app.dispatch;
        let component = state.currentuser;
        let compJson = component?.getJson();
        let opps = component?.getOperationsFactory();
        let styles=state.styles;
        let factory=state.factory;
        
        return (
            <div className="popup-boxa to-front" style={{ }} >

                <div ref={this.wrapperRef} className="card-container6abc1shedit" >
                    <div className="fill2 homeworkScroll1" >
                    <span className="close-icon-2" onClick={this.props.handleClose}>x</span>
                    <div style={{ width: "100%" }}>
                    
                    <h2 style={{display:"flex", flexDirection:"row", justifyContent:this.state.justifyContent}}>Edit User</h2>
                    <div className="form-group">
                            <label htmlFor="firstName"><b>First Name:</b></label>
                            <input type="text" className="form-control" id="first" placeholder={compJson?.firstName} onChange={opps?.handleChange} name="updatefirstName"/>
                        </div>
                        <div className="form-group">
                            <label htmlFor="lastName"><b>Last Name:</b></label>
                            <input type="text" className="form-control" id="last" placeholder={compJson?.lastName} onChange={opps?.handleChange} name="updatelastName"/>
                        </div>
                        <div className="form-group">
                            <label htmlFor="p"><b>Phone:</b></label>
                            <input type="text"className="form-control"id="p"  placeholder={compJson?.phone} onChange={opps?.handleChange} name="updatephone"/>
                        </div>
                        <div>

                           
                                <div className="form-group">
                            <label htmlFor="e"><b>Email:</b></label>
                            <input type="text" className="form-control" id="e"placeholder={compJson?.email} onChange={opps?.handleChange} name="updateemail"/>
                            <div style = {styles.buttons.buttonLog} 
                            onClick={dispatch.bind(this, {operate: "update", operation:"cleanPrepare", object:component, popupSwitch:"addPic"})}>Change Picture</div>  
                        </div>
                        <button className="btn btn-block" style={{ background: "#696eb5", height: "35px", color: "#F0F2EF", marginTop:"20px", width:"125px" }} onClick={dispatch.bind(this,{operation: "run", popupSwitch:""})}>
                                <span className="fill1"><p style={{ marginBottom: "10px" }}>Save</p></span></button> 

                               
                </div>
               </div>
               </div>
            </div>
            </div>
            

        )

    }
}
