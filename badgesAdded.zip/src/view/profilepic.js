import React, { Component } from 'react';
class ProfilePic extends Component {
    constructor(props) {
        //create state
        super(props);
        this.state = {
            
        };
    }
    

    render() {
       
        let app = this.props.app;
        let state = app.state;
        let styles =state.styles;
        let dispatch = app.dispatch;
        let list = state.componentList;
        let component = state.currentuser;
        let comp = component?.getJson();
        
        return (
            
            <div 
                 style={{
                     display:"flex", 
                     flexDirection:"column", 
                     justifycontent:"justify",
                     margintop: "2",
                     flex: .2,
                    //  marginTop: styles.margins.margin2,
                     border: styles.borders.borderthin,
                     alignItems: "center",

                     }}>
                        
                        
                         <div style={{
                             padding: styles?.borders?.paddingSpace,
                         }}> </div>
                <img style={{
                    width: "100px", 
                    height:"100px",
                    
                    border: styles?.borders?.borderPic,
                    justifycontent:"space-evenly",
                    fontSize: styles?.fonts?.fontsize2,

                    borderRadius:"50%"}}
                     src = {comp?.picURL} onClick={dispatch.bind(this, {operate: "update", operation:"cleanPrepare", object:component, popupSwitch:"addPic"})} />
                    
              <div>{comp?.firstName} {comp?.lastName}</div>
                <div style={{
                       
                        color: styles?.colors.colorLink,
                        fontSize: styles?.fonts.fontsize2,
                        justifyContent: "space-evenly",
                        paddingBottom: styles?.side.sidePadding
                    }}
                    onClick={dispatch.bind(this, {popupSwitch:"editUser",  operate: "update", operation:"cleanPrepare", object:component})}>
                       Edit Profile
                        </div>
                        <div style={{
                       
                       color: styles?.colors.colorLink,
                       fontSize: styles?.fonts.fontsize2,
                       justifyContent: "space-evenly",
                       paddingBottom: styles?.side.sidePadding
                   }}
                   onClick={dispatch.bind(this, {popupSwitch:"editUser",  operate: "update", operation:"cleanPrepare", object:component})}>
                      
                       </div>
            </div>
               
        );
    }
}

export default ProfilePic;