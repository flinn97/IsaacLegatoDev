import React, { Component } from 'react';
import authService from '../services/auth.service';

class ChatRoom extends Component {
    constructor(props) {
        //create state
        super(props);
        this.handleChange=this.handleChange.bind(this);
        this.state = {
            
        };
    }
    componentDidMount(){
        debugger
        let app=this.props.app;
        let state= app.state;
        let componentList = state.componentList;
        if(this.props.app.state.currentuser.getJson().role==="student"){
            authService.getGeneralChatPosts(this.props.app.state.currentuser.getJson().collection, componentList);
        }
        if(!this.props.app.state.currentChatroom){
            let chatRoom = this.props.app.state.componentList.getList("chatroom", "general", "name")[0];
        
            this.props.app.dispatch({currentChatroom:chatRoom })
            
            let list = this.props.app.state.componentList.getList("post", "generalChatroom", "chatroom");
            let list2=[]
            for(const key in list){
               if(!list[key].getJson().read){
                   list[key].setJson({...list[key].getJson(), read:true})
                   list2.push(list[key])
               }
            }
            let dispatch= app.dispatch
            dispatch({operate:"update", operation:"prepareRun", object: list2})
        }
        
    }
    handleChange(e){
        
        let app = this.props.app;
        let state = app.state;
        let list = state.componentList;
        let opps = list.getOperationsFactory();
        let comp = opps.getUpdater().getJson().add[0];
        comp.getOperationsFactory().handleChange(e)
    }
    

    render() {
        let app = this.props.app;
        let state = app.state;
        let styles =state.styles;
        let dispatch = app.dispatch;
        let list = state.componentList;
        let posts = list.getList("post", state?.currentChatroom?.getJson()._id, "chatroom");
        let opps = list.getOperationsFactory();

        return (
            <div style={
                    styles.biggestcard}>
            <div style={{
                    padding: this.props.app.state.styles.margins.margin4,
                    fontSize: this.props.app.state.styles.fonts.fontsize1,
                    fontFamily: this.props.app.state.styles.fonts.appFont,
                    fontWeight: this.props.app.state.styles.fonts.fontweightMed

            }}>Chat</div>
            <div style={{
                    display:"flex", 
                    flexDirection:"column",
                    padding: this.props.app.state.styles.margins.margin4,
                    justifyContent:"space-between",
                    height:"100%"
                }}>
                    <div>{posts.map((post, index) => <div>{post.getJson().content}</div>)}</div>
            <div > <div className="form-group">
                            <label htmlFor="lastName"><b>post:</b></label>
                            <input type="text" className="form-control" id="last" onChange={this.handleChange}  onClick={async ()=>{
                                debugger
                                let owner = state.currentuser.getJson()._id
                                if(state.currentChatroom.getJson()._id!=="generalChatroom"){
                                    owner = state.currentChatroom.getJson().owner
                                }
                                await dispatch({operation:"cleanJsonPrepare", operate:"addpost", object:{owner: owner,student:state.currentuser.getJson().role==="teacher"?false:true,  chatroom:state.currentChatroom.getJson()._id}})
                    }} name="addcontent"/>
                            <div onClick={dispatch.bind(this, {operation:"run"})}>send</div>
                        </div>
                        </div>
            </div>
            </div>
               
        );
    }
}

export default ChatRoom;